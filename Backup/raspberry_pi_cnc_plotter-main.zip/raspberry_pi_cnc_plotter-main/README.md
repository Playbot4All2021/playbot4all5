# raspberry_pi_cnc_plotter
My Raspberry Pi controlled CNC plotter
